<?php

require_once __DIR__ . "/../conexion.php";


$resultadoCategorias = mysqli_query($conn, "SELECT * FROM categorias");

// Consulta para obtener todas las categorías
$resultadoLocal = mysqli_query($conn, "SELECT * FROM club");

// Consulta para obtener todos los clubes
$resultadoVisitante = mysqli_query($conn, "SELECT * FROM club");

// Verifica si el formulario fue enviado mediante POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

$local = $_POST["EquipoLocal"];
$visitante = $_POST["EquipoVisitante"];
$categoria = $_POST["Categoria"];
$fecha = $_POST["fecha"];

if ($fecha == "") {
    $estado = "sin_fecha";
} else {
    $estado = "programado";
}
}