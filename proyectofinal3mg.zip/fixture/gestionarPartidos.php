<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "PHP funciona correctamente";

require_once __DIR__ . "/../conexion.php";
echo "<br>Conexión incluida correctamente";

include("agregarPartido.php");
echo "<br>Agregar partido cargado";

include("listarPartidos.php");
echo "<br>Listar partidos cargado";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Partidos</title>
    <link rel="stylesheet" href="partidos.css">
</head>
<body>
    <h1>Gestión de partidos</h1>
</body>
</html>