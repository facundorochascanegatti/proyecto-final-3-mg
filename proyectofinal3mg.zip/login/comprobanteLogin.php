<?php
require_once __DIR__ . "/../conexion.php";
require_once __DIR__ . "/../sesion.php";

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: login.php");
    exit();
}

$usuario = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";

// Consulta con prepare: así no se puede meter SQL en el usuario
$stmt = mysqli_prepare($conn, "SELECT usuario, `contraseña`, rol, id_club FROM usuarios WHERE usuario = ?");

// lo de abajo vincula la variable $usuario con el parámetro ? de la consulta preparada.
// La "s" indica que el dato es de tipo texto (string).
mysqli_stmt_bind_param($stmt, "s", $usuario);
mysqli_stmt_execute($stmt);

// obtiene el resultado de la consulta y lo guarda en un array asociativo
// stmt es statment, que es un objeto que representa la consulta preparada para poder obtener el resultado de la consulta, se usa mysqli_stmt_get_result
$fila = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

try {
    if (!$fila || !password_verify($password, $fila["contraseña"])) {
        throw new Exception("Usuario o contraseña incorrectos.");
    }
} catch (Exception $e) {
    header("Location: login.php?error=1");
    exit();
}

iniciarSesionPorRol($fila["rol"]);
session_regenerate_id(true);
$_SESSION["usuario"] = $fila["usuario"];
$_SESSION["rol"] = $fila["rol"];
$_SESSION["id_club"] = $fila["id_club"];

if ($fila["rol"] === "admin") {
    header("Location: ../admin/indexadmin.php");
} else {
    header("Location: ../club/indexclub.php");
}
exit();

header("Location: login.php?error=1");
exit();
