<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario  = $_POST["username"];
    $password = $_POST["password"];

    $conn = mysqli_connect("localhost", "root", "", "liga");

    $sql = "SELECT contraseña FROM usuarios WHERE usuario = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    
    mysqli_stmt_bind_param($stmt, "s", $usuario);
    
    mysqli_stmt_execute($stmt);
    
    $fila = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($fila && password_verify($password, $fila["contraseña"])) {
    $_SESSION["usuario"] = $usuario;
    // ... el resto queda igual (el if del admin y el header)

    mysqli_close($conn);
    }
}
?>